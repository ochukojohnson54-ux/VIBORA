import { AppShell } from "@/components/app-shell";
import Link from "next/link";
const data: Record<string,{title:string;desc:string;placeholder:string}> = {
 image:{title:"AI Image Studio",desc:"Describe the image you want to create. Connect an image provider to enable generation.",placeholder:"A cinematic portrait in warm golden-hour light…"},
 video:{title:"AI Video Lab",desc:"Prepare text-to-video or image-to-video concepts. A video provider connection is required to render clips.",placeholder:"A cinematic tracking shot of a bustling Lagos street at dusk…"},
 movie:{title:"Movie Studio",desc:"Develop your film concept, characters, scenes and production notes.",placeholder:"Enter your movie title, premise or scene idea…"},
 design:{title:"Design Lab",desc:"Plan posters, flyers, thumbnails and branded graphics.",placeholder:"A dramatic Nollywood movie poster with…"},
 audio:{title:"Music & Audio Studio",desc:"Organize soundtrack concepts, narration and sound design.",placeholder:"Describe the mood, instruments or voiceover…"}
};
export default async function StudioPage({params}:{params:Promise<{studio:string}>}) {
 const {studio}=await params; const item=data[studio] ?? data.movie;
 return <AppShell><Link href="/dashboard" className="text-sm text-violet-300">← Back to dashboard</Link><div className="mt-6 max-w-3xl"><p className="text-xs font-bold tracking-[.2em] text-violet-300">VIBORA CREATIVE WORKSPACE</p><h1 className="mt-3 text-3xl font-bold">{item.title}</h1><p className="mt-3 leading-7 text-zinc-400">{item.desc}</p><form className="card mt-8 space-y-4 p-5" action="/api/projects" method="post"><input type="hidden" name="studio" value={studio}/><label className="block text-sm font-medium">Project title<input name="title" className="field mt-2" placeholder="Give your project a name" required/></label><label className="block text-sm font-medium">Creative brief<textarea name="prompt" className="field mt-2 min-h-36 resize-y" placeholder={item.placeholder} required/></label><button className="btn-primary" type="submit">Save project brief</button><p className="text-xs text-zinc-500">Saving requires Supabase setup and a signed-in account. AI rendering will be enabled when a provider is connected.</p></form></div></AppShell>;
}